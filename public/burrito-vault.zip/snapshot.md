---
title: Market Snapshot
tags: [burrito, snapshot]
updated: 2026-08-01
---

# Market Snapshot — 2026-08-01

Auto-generated daily by the burrito pipeline. See [[data-pipeline]] for how.

## Bitcoin

- **Price**: $62,811.4 · **Risk**: 0.022 ([[risk-metric|methodology]])
- **Fair value** (fan median): $113,351.47
- **MVRV**: 1.1887 · **NUPL**: 0.1588 · **Puell**: 0.828
- **Fear & Greed**: 27

## Market

- **Total market cap** (tracked): $1912.949B · **BTC dominance**: 65.82% · **SSR**: 4.88

## Top assets by market cap

| Asset | Price | 24h | Risk |
|---|---|---|---|
| BTC | $62,811 | -2.95% | 0.01 |
| ETH | $1,758 | +3.39% | 0.02 |
| XRP | $1.1348 | +4.29% | 0.47 |
| BNB | $574 | +2.66% | 0.01 |
| SOL | $82.34 | +1.99% | 0.11 |
| TRX | $0.3234 | +1.83% | 0.50 |
| XLM | $0.2041 | +2.41% | 0.54 |
| DOGE | $0.0775 | +4.53% | 0.01 |
| LINK | $7.975 | +2.94% | 0.05 |
| ADA | $0.1798 | +11.33% | 0.02 |

*Not financial advice. Just a burrito.* 🌯
