---
title: Market Snapshot
tags: [burrito, snapshot]
updated: 2026-09-09
---

# Market Snapshot — 2026-09-09

Auto-generated daily by the burrito pipeline. See [[data-pipeline]] for how.

## Bitcoin

- **Price**: $78,444.05 · **Risk**: 0.129 ([[risk-metric|methodology]])
- **Fair value** (fan median): $115,050.3
- **MVRV**: 1.4703 · **NUPL**: 0.3199 · **Puell**: 1.074
- **Fear & Greed**: 69

## Market

- **Total market cap** (tracked): $2351.725B · **BTC dominance**: 66.78% · **SSR**: 6.04

## Top assets by market cap

| Asset | Price | 24h | Risk |
|---|---|---|---|
| BTC | $78,444 | -0.82% | 0.10 |
| ETH | $1,758 | +3.39% | 0.02 |
| XRP | $1.1348 | +4.29% | 0.47 |
| BNB | $574 | +2.66% | 0.01 |
| SOL | $82.34 | +1.99% | 0.11 |
| TRX | $0.3234 | +1.83% | 0.50 |
| XLM | $0.2041 | +2.41% | 0.54 |
| DOGE | $0.0775 | +4.53% | 0.01 |
| LINK | $7.975 | +2.94% | 0.05 |
| ADA | $0.1798 | +11.33% | 0.02 |

*Not financial advice. Just a burrito.* 🌯
